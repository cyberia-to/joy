"""Retain this local smoke's exact completed evidence; never rewrites the inputs."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import tarfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'portable-native-smoke/joy/audit/portable-native-smoke'
MEASUREMENTS = ROOT / 'measurements'

def sha(data):
    return hashlib.sha256(data).hexdigest()

members = {}
for prefix, directory in [('initial', 'portable-native-smoke'), ('final', 'portable-native-smoke-final')]:
    for path in sorted((MEASUREMENTS / directory).rglob('*')):
        if path.is_symlink():
            raise ValueError('symlink in owned measurements')
        if path.is_file():
            members[f'{prefix}/{path.relative_to(MEASUREMENTS / directory).as_posix()}'] = path.read_bytes()
for name in ('run-portable-native-smoke.py', 'run-portable-native-smoke-final.py', 'collect-portable-native-smoke.py'):
    members['drivers/' + name] = (MEASUREMENTS / name).read_bytes()
validation = json.loads(members['final/validation.json'])
smoke = json.loads(members['final/installed/receipt.json'])
if validation['status'] != 'passed' or smoke['status'] != 'passed':
    raise ValueError('completed passed receipts required')
if validation['before'] != validation['after']:
    raise ValueError('frozen nine-source identities changed')
if smoke['binary_start'] != smoke['binary_end'] or smoke['script_start'] != smoke['script_end']:
    raise ValueError('installed inputs changed')
for row in validation['commands']:
    if row['exit_code'] != 0 or row['warning_lines'] != 0:
        raise ValueError('unsuccessful gate')
    for stream in ('stdout', 'stderr'):
        data = members['final/' + row[stream]['path']]
        if dict(bytes=len(data), sha256=sha(data)) != {k:row[stream][k] for k in ('bytes','sha256')}:
            raise ValueError('gate log identity')
for row in smoke['commands']:
    if row['exit_code'] != row['expected_exit'] or row['status'] != 'completed':
        raise ValueError('smoke command status')
    for stream in ('stdout', 'stderr'):
        data = members['final/installed/' + row[stream]]
        if dict(bytes=len(data), sha256=sha(data)) != row[stream + '_identity']:
            raise ValueError('command log identity')
for name, expected in smoke['work_files'].items():
    data = members['final/installed/work/' + name]
    if dict(bytes=len(data), sha256=sha(data)) != expected:
        raise ValueError('work identity')
index = {name: dict(bytes=len(data), sha256=sha(data)) for name, data in sorted(members.items())}
encoded_index = (json.dumps(index, indent=2) + '\n').encode()
with (OUT/'raw-evidence.tar.gz').open('xb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                archive.addfile(info, io.BytesIO(data))
with tarfile.open(OUT/'raw-evidence.tar.gz', 'r:gz') as archive:
    if archive.getnames() != sorted(members):
        raise ValueError('archive file set')
    for member in archive:
        if not member.isfile() or archive.extractfile(member).read() != members[member.name]:
            raise ValueError('archive bytes')
with (OUT/'files.json').open('xb') as output:
    output.write(encoded_index)
counts = re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', members['final/tests.stdout'])
summary = dict(schema='joy/portable-native-smoke-audit/v1', status='passed',
    scope='One local macOS ARM installed Joy regression, later Nox/Zheng pins; no SH6, SH7, SH8 or release acceptance',
    inputs=validation['before'], installed_binary=smoke['binary_start'],
    raw_validation='final/validation.json', raw_smoke='final/installed/receipt.json',
    initial_failed_setup='initial/validation.json',
    initial_failure='Cargo install exited 0 but emitted the missing-PATH advisory; driver stopped. No smoke or compiler test ran in that attempt.',
    final_path_correction='Final build driver prepends its installed bin directory to PATH; smoke restricts PATH to exactly that directory.',
    commands=len(smoke['commands']), successful_commands=sum(c['expected_exit']==0 for c in smoke['commands']),
    rejected_commands=sum(c['expected_exit']==1 for c in smoke['commands']), work_files=len(smoke['work_files']),
    routes=smoke['routes'], rust_summaries=len(counts),
    rust_totals=dict(zip(('passed','failed','ignored'), map(sum, zip(*(tuple(map(int,c)) for c in counts))))),
    python_guards_per_mode=9, python_modes=['normal','optimized'], warning_lines=0,
    archive=dict(path='raw-evidence.tar.gz', bytes=(OUT/'raw-evidence.tar.gz').stat().st_size,
                 sha256=sha((OUT/'raw-evidence.tar.gz').read_bytes()), files=len(members), raw_bytes=sum(map(len,members.values()))),
    index=dict(path='files.json', sha256=sha(encoded_index)))
with (OUT/'receipt.json').open('x') as output:
    output.write(json.dumps(summary, indent=2)+'\n')
print(json.dumps({k: summary[k] for k in ('archive','rust_totals','commands','index')}, indent=2))
