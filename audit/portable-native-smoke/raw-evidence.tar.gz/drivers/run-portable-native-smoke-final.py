from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
FAMILY = ROOT / "portable-native-smoke"
JOY = FAMILY / "joy"
OUT = ROOT / "measurements/portable-native-smoke-final"
PREFIX = ROOT / "install-portable-native-smoke"
NAMES = ("bbg", "hemera", "joy", "lens", "neuron", "nox", "strata", "trident", "zheng")
FILES = ("scripts/smoke-native.py", "scripts/test_smoke_native.py", "rs/examples/release_state_fixtures.rs")
OUT.mkdir()
(OUT/"source").mkdir()
for name in FILES:
    destination = OUT/"source"/name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((JOY/name).read_bytes())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def sources():
    return dict(repositories={n: dict(
        revision=subprocess.check_output(["git", "-C", str(FAMILY/n), "rev-parse", "HEAD"], text=True).strip(),
        status=subprocess.check_output(["git", "-C", str(FAMILY/n), "status", "--porcelain", "--untracked-files=all"], text=True))
        for n in NAMES}, delivery={name: sha(JOY/name) for name in FILES})

report = dict(scope="Local isolated installed-Joy regression; no SH6/SH7 or release acceptance",
              started=datetime.datetime.now(datetime.timezone.utc).isoformat(), driver_sha256=sha(Path(__file__)),
              before=sources(), commands=[], status="running")

def flush():
    (OUT/"validation.json").write_text(json.dumps(report, indent=2)+"\n")

env = dict(os.environ, CARGO_TARGET_DIR=str(ROOT/"target-portable-native-smoke"), PYTHONDONTWRITEBYTECODE="1")
for name in ("RUSTC", "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER", "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "CARGO_BUILD_TARGET", "PYTHONOPTIMIZE"):
    env.pop(name, None)
env["PATH"] = str(PREFIX/"bin") + os.pathsep + env["PATH"]
report["env"] = {"PATH": env["PATH"], "CARGO_TARGET_DIR": env["CARGO_TARGET_DIR"], "PYTHONDONTWRITEBYTECODE": "1"}
commands = [
    ("rust-version", ["rustc", "-vV"]),
    ("guards", ["python3", "-B", "-W", "error", "scripts/test_smoke_native.py"]),
    ("guards-optimized", ["python3", "-B", "-O", "-W", "error", "scripts/test_smoke_native.py"]),
    ("format", ["rustfmt", "--check", "--edition", "2021", "rs/examples/release_state_fixtures.rs"]),
    ("boundary", ["python3", "scripts/check-soft3-boundary.py"]),
    ("install", ["cargo", "install", "--path", "cli", "--force", "--root", str(PREFIX), "--locked", "--offline"]),
    ("fixtures", ["cargo", "run", "--release", "--locked", "--offline", "-p", "joy-rs", "--example", "release_state_fixtures", "--", str(OUT/"fixtures")]),
    ("smoke", ["python3", "-B", "-W", "error", "scripts/smoke-native.py", "--joy", str(PREFIX/"bin/joy"), "--fixtures", str(OUT/"fixtures"), "--output", str(OUT/"installed")]),
    ("check", ["cargo", "check", "--workspace", "--all-targets", "--release", "--locked", "--offline"]),
    ("tests", ["cargo", "test", "--workspace", "--release", "--locked", "--offline"]),
    ("diffcheck", ["git", "diff", "--check"]),
]
flush()
try:
    for name, argv in commands:
        row = dict(name=name, argv=argv, cwd=str(JOY), status="running", exit_code=None)
        report["commands"].append(row); flush()
        started = time.monotonic_ns()
        with (OUT/(name+".stdout")).open("xb") as stdout, (OUT/(name+".stderr")).open("xb") as stderr:
            result = subprocess.run(argv, cwd=JOY, env=env, stdout=stdout, stderr=stderr, timeout=3600)
        row.update(status="completed", exit_code=result.returncode, elapsed_ns=time.monotonic_ns()-started)
        for stream in ("stdout", "stderr"):
            path = OUT/(name+"."+stream)
            row[stream] = dict(path=path.name, bytes=path.stat().st_size, sha256=sha(path))
        row["warning_lines"] = len(re.findall(rb"^warning(?:\[[^\]\r\n]+\])?:", (OUT/(name+".stderr")).read_bytes(), re.M))
        flush()
        print(name, result.returncode, "warnings", row["warning_lines"], flush=True)
        if result.returncode or row["warning_lines"]:
            raise RuntimeError(f"{name} failed")
    report["status"] = "passed"
except BaseException as error:
    report.update(status="failed", error=f"{type(error).__name__}: {error}")
finally:
    report["after"] = sources()
    report["ended"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    flush()
raise SystemExit(0 if report["status"] == "passed" else 1)
